﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Alumno
    {
        private byte nota1;
        private byte nota2;
        private float notaFinal;
        public string apellido;
        public int legajo;
        public string nombre;

        public Alumno(string nombre, string apellido, int legajo)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.legajo = legajo;
        }

        public void CalcularFinal()
        {
            if (nota1 >= 4 && nota2 >= 4)
            {
                Random rnd = new Random();
                int min = 1;
                int max = 10;
                notaFinal = rnd.Next(min, max);
            }
            else
            {
                notaFinal = -1;
            }

        }
        public void Estudiar(byte notaUno, byte notaDos)
        {
            nota1 = notaUno;
            nota2 = notaDos;
        }
        public string Mostrar()
        {
            string datos = "El nombre del alumno es: " + nombre + "\n" + "El apellido del alumno es: " +
                apellido + "\n" + "El legajo del alumno es: " + legajo + "\n" + "La nota del primer parcial del alumno es: " + nota1
                + "\n" + "La nota del segundo parcial del alumno es: " + nota2;

            if(notaFinal != -1)
            {
                datos += "\n" + "La nota final del alumno es: " + notaFinal;
            }
            return datos;
        }

    }
}
