﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_26
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> intList = new List<int>();
            Random random = new Random();

            for(int i = 0; i < 20; i++)
            {
                int randomNumber = random.Next(-100, 100);
                intList.Add(randomNumber);
            }

            Console.WriteLine("Antes de ordenar \n");
            foreach (var num in intList)
            {
                Console.WriteLine(num);
            }
            Console.ReadKey();
            
            intList.Sort();
            intList.Reverse();
            Console.WriteLine("\n Despues de ordenar decendente los positivos\n");
            foreach (var num in intList)
            {
                if(num >= 0)
                Console.WriteLine(num);
            }
            Console.ReadKey();

            intList.Sort();
            Console.WriteLine("Despues de ordenar acendiente los negativos\n");
            foreach (var num in intList)
            {
                if (num <= 0)
                    Console.WriteLine(num);
            }
            Console.ReadKey();
        }
    }
}
