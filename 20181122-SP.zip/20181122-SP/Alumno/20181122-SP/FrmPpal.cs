﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Entidades;
using Archivos;
using System.Threading;

namespace _20181122_SP
{
    public partial class FrmPpal : Form
    {
        Queue<Patente> cola;
        private List<Thread> hilos;

        public FrmPpal()
        {
            InitializeComponent();

            this.cola = new Queue<Patente>();
            hilos = new List<Thread>();
        }

        private void FrmPpal_Load(object sender, EventArgs e)
        {
            vistaPatente1.mostrarProximaPatente += ProximaPatente;
            vistaPatente2.mostrarProximaPatente += ProximaPatente;
        }

        private void FrmPpal_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.FinalizarSimulacion();
        }

        private void btnXml_Click(object sender, EventArgs e)
        {
            try
            {
                Xml<Queue<Patente>> patente = new Xml<Queue<Patente>>();
                patente.Leer(@"D:\VisualStudio\20181122-SP\patentes.xml", out cola);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private void btnTxt_Click(object sender, EventArgs e)
        {
            try
            {
                Texto texto = new Texto();
                texto.Leer(@"D:\VisualStudio\20181122-SP\patentes.txt", out cola);
            }
            catch (Exception exception)
            {
                throw exception;
            }
           
        }

        private void btnSql_Click(object sender, EventArgs e)
        {

        }

        private void FinalizarSimulacion()
        {
            foreach (Thread hilo in hilos)
            {
                hilo.Abort();
            }
        }

        private void IniciarSimulacion()
        {
            foreach (Thread hilo in hilos)
            {
                if (hilo.IsAlive)
                {
                    hilo.Abort();
                }
            }

            this.ProximaPatente(vistaPatente1);
            this.ProximaPatente(vistaPatente2);
        }

        public void ProximaPatente(object patente)
        {
           Thread hilo = new Thread();
        }
    }
}
