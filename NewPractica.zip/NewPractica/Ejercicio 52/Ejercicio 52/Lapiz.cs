﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_52
{
    public class Lapiz : IAcciones
    {
        private float tamanioMina;

        public ConsoleColor Color
        {
            get
            {
                return ConsoleColor.Gray;
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public float UnidadesDeEscritura
        {
            get
            {
                return tamanioMina;
            }
            set
            {
                tamanioMina = value;
            }
        }

        EscrituraWrapper IAcciones.Escribir(string texto)
        {
            float caracteres = texto.Length;
            UnidadesDeEscritura = (float)(UnidadesDeEscritura - (caracteres * 0.1));
            return new EscrituraWrapper(texto, Color);
        }

        public Lapiz(int unidades)
        {
            UnidadesDeEscritura = unidades;
        }

        bool IAcciones.Recargar(int unidades)
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return String.Format("Lapiz, Color: {0}, Nivel de tinta: {1}", Color, UnidadesDeEscritura);
        }
    }
}
