﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_15
{
    class Program
    {
        static void Main(string[] args)
        {
            string auxNumero1;
            string auxNumero2;
            double numero1;
            double numero2;
            string operador;
            double resultado;

            Console.WriteLine("Ingresar el primer numero");
            auxNumero1 = Console.ReadLine();

            Console.WriteLine("Ingresar el operador");
            operador = Console.ReadLine();

            Console.WriteLine("Ingresar el segundo numero");
            auxNumero2 = Console.ReadLine();

            bool trueOrFalseNumero1 = double.TryParse(auxNumero1, out numero1);
            bool trueOrFalseNumero2 = double.TryParse(auxNumero2, out numero2);

            if(trueOrFalseNumero1 && trueOrFalseNumero2)
            {
                resultado = Calculadora.Calcular(numero1, numero2, operador);
                Console.WriteLine("El resultado es: " + resultado);
                Console.ReadKey();
            }


        }
    }
    class Calculadora
    {
        public static double Calcular(double numero1, double numero2, string operador)
        {
            double rv = 0;
            if (operador == "+")
            {
                rv = numero1 + numero2;
            }
            else if(operador == "-")
            {
                rv = numero1 - numero2;
            }
            else if(operador == "*")
            {
                rv = numero1 * numero2;
            }
            else if(operador == "/")
            {
                bool trueORFalse = Calculadora.Validar(numero2);

                if (trueORFalse)
                {
                    rv = numero1 / numero2;
                }
                else
                {
                    Console.WriteLine("El divisor no puede ser 0");
                }
                
            }
            return rv;

        }
        private static bool Validar(double divisor)
        {
            bool rv =  false;
            if (divisor != 0)
            {
                rv = true;
            }
            return rv;
        }
    }
}
