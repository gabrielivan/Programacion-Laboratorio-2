using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_12;

namespace Ejercicio_12
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 10;
            char rs;
            string aux;
            bool esValido = false;
            do
            {
                i += i;
                Console.WriteLine("El resultado de la suma es: " + i);
                Console.WriteLine("¿Continuar? (S/N): ");
                aux = Console.ReadLine();

                bool trueOrFalse = char.TryParse(aux, out rs);
                if (trueOrFalse)
                {
                    esValido  = ValidarRespuesta.ValidaS_N(rs);
                    if (esValido)
                    {
                        rs = 'S';
                    }
                    else if(rs != 'N')
                    {
                        Console.WriteLine("Error!, Ingrese (S/N)");
                        Console.ReadKey();
                    }

                }

            } while (rs == 'S');

        }
    }
    public class ValidarRespuesta
    {
        public static bool ValidaS_N(char c)
        {
            var rv = false;

            if (c == 'S')
            {
                rv = true;
            }
            return rv;
        }
    }
}
