﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto
{
    class Producto
    {
        private string codigoDeBarra;
        private string marca;
        private float precio;

        public Producto(string marca, string codigo, float precio)
        {
            this.marca = marca;
            this.precio = precio;
            this.codigoDeBarra = codigo;
        }

        public string GetMarca()
        {
            return this.marca;
        }
        public float GetPrecio()
        {
            return this.precio;
        }
        public static string MostrarProducto(Producto p)
        {
            string cadena = "";
            cadena += "La marca es: " + p.marca + "\n" + "El precio es: " + p.precio + "\n" + "El codigo de barra es: " + p.codigoDeBarra + "\n";
            return cadena;
        }

        public static explicit operator string(Producto p)
        {
            return p.codigoDeBarra;
        }
        public static bool operator==(Producto p1, Producto p2)
        {
            bool rv = false;
            if (p1.marca == p2.marca && p1.codigoDeBarra == p2.codigoDeBarra)
            {
                rv = true;
            }
            return rv;
        }
        public static bool operator==(Producto p, string marca)
        {
            bool rv = false;
            if (p.marca == marca)
            {
                rv = true;
            }
            return rv;
        }
        public static bool operator !=(Producto p1, Producto p2)
        {
            return !(p1 == p2);
        }
        public static bool operator !=(Producto p, string marca)
        {
            return !(p == marca);
        }
    }
}
