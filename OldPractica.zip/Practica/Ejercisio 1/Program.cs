﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica
{
    class Program
    {
        static void Main(string[] args)
        {
            int acumulador = 0;
            int promedio = 0;
            int numero;
            int min = int.MinValue;
            int max = int.MaxValue;
            bool flag = true;
            for (int i = 0; i < 5; i++)
            {
                string aux;
                Console.WriteLine("Numero {0}", i);
                aux = Console.ReadLine();

                bool trueOrFalse = int.TryParse(aux, out numero);
                if(trueOrFalse)
                {
                    acumulador = acumulador + numero;

                    if (flag)
                    {
                        min = numero;
                        max = numero;
                        flag = false;
                    }
                    else
                    {
                        if(numero < min)
                        {
                            min = numero;
                        }
                        else if(numero > max)
                        {
                            max = numero;
                        }

                    }
                    

                }
            }
            promedio = acumulador / 5;

            Console.WriteLine(acumulador);
            Console.WriteLine(max);
            Console.WriteLine(min);
            Console.WriteLine(promedio);
            Console.ReadKey();

        }
    }
}

