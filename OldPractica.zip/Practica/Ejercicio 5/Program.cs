﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_5
{
    class Program
    {
        static void Main(string[] args)
        {
            string aux;
            int numero;
            int acumuladorUno = 0;
            int acumuladorDos = 0;

            Console.WriteLine("Ingresar el numero: ");
            aux = Console.ReadLine();

            bool trueOrFalse = int.TryParse(aux, out numero);
            if (trueOrFalse)
            {
                for (int k = 1; k < numero; k++)
                {
                    for (int i = 1; i < k; i++)
                    {
                        acumuladorUno += i;
                    }
                    for (int j = k + 1; acumuladorDos <= acumuladorUno; j++)
                    {
                        acumuladorDos += j;
                        if (acumuladorDos == acumuladorUno)
                        {
                            //Es un centro numerico
                            Console.WriteLine("Es un centro numerico ---> " + k);
                            break;
                        }

                    }
                    acumuladorDos = 0;
                    acumuladorUno = 0;
                }
            }
            Console.ReadKey();
        }
    }
}
