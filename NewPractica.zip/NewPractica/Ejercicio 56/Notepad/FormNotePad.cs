﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Notepad
{
    public partial class FormNotePad : Form
    {
        string archivoAbierto;

        public FormNotePad()
        {
            InitializeComponent();
        }

        private void toolStripMenuItemAbrir_Click(object sender, EventArgs e)
        {
            string rutaDelArchivo;
            OpenFileDialog abridorDeArchivos = new OpenFileDialog();

            abridorDeArchivos.InitialDirectory = "C://";

            if (abridorDeArchivos.ShowDialog() == DialogResult.OK)
            {
                //Obtiene la ruta del archivo especifico
                rutaDelArchivo = abridorDeArchivos.FileName;
                archivoAbierto = rutaDelArchivo;
                StreamReader stream = new StreamReader(rutaDelArchivo);
                richTextBox.Text = stream.ReadToEnd();
                stream.Close();
            }
        }

        private void toolStripMenuItemGuardar_Click(object sender, EventArgs e)
        {
            if (File.Exists(archivoAbierto))
            {
                StreamWriter textoAGuardar = new StreamWriter(archivoAbierto);
                textoAGuardar.Write(richTextBox.Text);
            }
            else
            {
                this.toolStripMenuItem4GuardaComo_Click(sender, e);
            }
        }

        private void toolStripMenuItem4GuardaComo_Click(object sender, EventArgs e)
        {
            SaveFileDialog guardadorDeArchivos = new SaveFileDialog();
            string rutaArchivo;
            guardadorDeArchivos.InitialDirectory = "C:\\";
            if (guardadorDeArchivos.ShowDialog() == DialogResult.OK)
            {
                rutaArchivo = guardadorDeArchivos.FileName;
                StreamWriter textoAGuardear = new StreamWriter(rutaArchivo);
                if (File.Exists(rutaArchivo))
                {
                    textoAGuardear.Write(richTextBox.Text);
                    textoAGuardear.Close();
                }
            }
        }

        private void richTextBox_TextChanged(object sender, EventArgs e)
        {
            toolStripStatusLabelCaracteres.Text = richTextBox.TextLength.ToString() + " caracteres";
        }
    }
}
