﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Ejercicio_61
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonLeer_Click(object sender, EventArgs e)
        {
            listPersona.Items.Clear();
            textBoxNombre.Text = "";
            textBoxApellido.Text = "";

            List<Persona> personas = PersonaDAO.Leer();

            foreach (Persona p in personas)
            {
                listPersona.Items.Add(p);
            }

        }

        private void buttonGuardar_Click(object sender, EventArgs e)
        {
            Persona personaAux = (Persona)listPersona.SelectedItem;
            PersonaDAO.Guardar(textBoxNombre.Text, textBoxApellido.Text);

        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            Persona personaAux = (Persona)listPersona.SelectedItem;
            PersonaDAO.borrar(personaAux.ID);

        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            Persona personaAux = (Persona)listPersona.SelectedItem;
            PersonaDAO.Modificar(new Persona(personaAux.ID, textBoxNombre.Text, textBoxApellido.Text));
        }

        private void listPersona_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Persona personaAux = (Persona)listPersona.SelectedItem;
            textBoxNombre.Text = personaAux.Nombre;
            textBoxApellido.Text = personaAux.Apellido;
        }
    }
}
