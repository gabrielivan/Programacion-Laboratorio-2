﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercisio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string aux;
            int numero;
            double numeroElevadoCuadrado = 0;
            double numeroElevadoCubo = 0;
            Console.WriteLine("Ingresar el numero");
            aux = Console.ReadLine();

            bool trueOrFalse = int.TryParse(aux, out numero);
            if (trueOrFalse)
            {
                if(numero > 0)
                {
                    numeroElevadoCuadrado = Math.Pow(numero, 2);
                    numeroElevadoCubo = Math.Pow(numero, 3);
                }
                else
                {
                    Console.WriteLine("Error,Reingresar el numero!");
                }
            }
            Console.WriteLine(numeroElevadoCuadrado);
            Console.Write(numeroElevadoCubo);
            Console.ReadKey();
        }
    }
}
