﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_19;


namespace Ejercicio_19
{
    class Sumador
    {

        private int cantidadSumas; //unico campo de la clase

        public Sumador(int numero) // primer constructor
        {
            this.cantidadSumas = numero;
        }
        public Sumador() // segundo constructor
        {
            this.cantidadSumas = 0;
        }

        public long Sumar(long numero, long numeroDos)
        {
            long resultado;
            this.cantidadSumas++;
            resultado = numero + numeroDos;
            return resultado;
        }
        public string Sumar(string cadenaUno, string cadenaDos)
        {
            string resultado;
            this.cantidadSumas++;
            resultado = cadenaUno + " " + cadenaDos;
            return resultado;
        }

        public static explicit operator int(Sumador a)
        {
            return a.cantidadSumas;
        }

        public static long operator +(Sumador a, Sumador b)
        {
            return a.cantidadSumas + b.cantidadSumas;
        }

        public static bool operator | (Sumador a, Sumador b)
        {
            bool rv = false;

            if (a.cantidadSumas == b.cantidadSumas)
            {
                rv = true;
            }
            return rv;
        }
    }
}
