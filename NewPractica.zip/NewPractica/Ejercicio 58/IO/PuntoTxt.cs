﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace IO
{
    [Serializable]
    public class PuntoTxt : Archivo, IArchivos<String>
    {
        public bool Guardar(string ruta, string objeto)
        {
            bool retorno = false;

            try 
            {
                if (File.Exists(ruta))
                {
                    StreamWriter rutaDelArchivo = new StreamWriter(ruta, true);//obtengo el archivo ubicado en la ruta que me pasaron por parametro -- le mando true para agregarle contenido al archivo que ya existe
                    rutaDelArchivo.WriteLine(objeto);//guardas el objeto en el archivo que conseguiste con la ruta pasada por parametro.
                    rutaDelArchivo.Close();

                    retorno = true;
                }
            }
            catch (FileNotFoundException)
            {
                
            }

            return retorno;

        }

        public bool GuardarComo(string ruta, string objeto)
        {
            bool retorno = false;

            try
            {
                if (File.Exists(ruta))
                {
                    StreamWriter rutaDelArchivo = new StreamWriter(ruta, false);//obtengo el archivo ubicado en la ruta que me pasaron por parametro -- le mando false para que me cree un archivo nuevo
                    rutaDelArchivo.WriteLine(objeto);//guardas el objeto en el archivo que conseguiste con la ruta pasada por parametro.
                    rutaDelArchivo.Close();

                    retorno = true;
                }
            }
            catch (FileNotFoundException)
            {

            }

            return retorno;
        }

        public string Leer(string ruta)
        {
            string retorno = "";

            if (this.ValidarArchivo(ruta,true))
            {
                StreamReader archivo = new StreamReader(ruta);//obtengo el archivo ubicado en la ruta que me pasaron por parametro
                retorno = archivo.ReadToEnd(); //leo hasta el final y retorno el string ya leido.                 
            }

            return retorno;

        }

        protected override bool ValidarArchivo(string ruta, bool validarExistencia)
        {
            if (Path.GetExtension(ruta) != ".txt")
            {
                throw new ArchivoIncorrectoException("El archivo no es un txt");
            }
            if (validarExistencia)
            {
                try
                {
                    base.ValidarArchivo(ruta, true);
                }
                catch (FileNotFoundException exception)
                {
                    throw new ArchivoIncorrectoException("El archivo no es correcto", exception);
                }
            }

            return true;
        }

    }
}