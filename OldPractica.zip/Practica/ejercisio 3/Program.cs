﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercisio_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string aux;
            int numero;

            Console.WriteLine("Ingresar el numero");
            aux = Console.ReadLine();

            bool trueOrFalse = int.TryParse(aux, out numero);
            if (trueOrFalse)
            {
                for(int i = numero;i > 0; i--)
                {
                    if (EsPrimo(i))
                    {
                        Console.WriteLine(i);
                    }
                }
            }
            Console.ReadKey();
        }
        public static bool EsPrimo(int numero)
        {
            bool rv = true;

            for(int i = 2;i < numero ; i++)
            {
                if(numero % i == 0)
                {
                    rv = false;
                    break;
                }

            }
            return rv;
        }
    }
}
