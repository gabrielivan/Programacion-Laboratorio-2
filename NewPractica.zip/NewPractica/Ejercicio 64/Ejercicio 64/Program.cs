﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using System.Threading;

namespace Ejercicio_64
{
    class Program
    {
        static void Main(string[] args)
        {
            Caja caja1 = new Caja();
            Caja caja2 = new Caja();
            Negocio negocio = new Negocio(caja1, caja2);
            negocio.Clientes.Add("Dami");
            negocio.Clientes.Add("Lean");
            negocio.Clientes.Add("Gaby");
            negocio.Clientes.Add("Lean");

            negocio.Clientes.Add("Dami");
            Thread tAsignarCajas = new Thread(negocio.asignarCaja);
            tAsignarCajas.Start();
            Thread tAtenderClientesCaja1 = new Thread(caja1.atenderClientes);
            tAtenderClientesCaja1.Start();
            Thread tAtenderClientesCaja2 = new Thread(caja2.atenderClientes);
            tAtenderClientesCaja2.Start();

        }
    }
}
