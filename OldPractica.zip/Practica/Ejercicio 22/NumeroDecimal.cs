﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_22
{
    class NumeroDecimal
    {
        private double numero;

        private NumeroDecimal(double d)
        {
            this.numero = d;
        }

        public static implicit operator NumeroDecimal(double d)
        {
            return new NumeroDecimal(d);
        }

        public static explicit operator double(NumeroDecimal numD)
        {
            return numD.numero;
        }

        public static string operator +(NumeroDecimal numD, NumeroBinario numB)
        {
            return numB + numD;
        }

        public static string operator -(NumeroDecimal numD, NumeroBinario numB)
        {
            return numB - numD;
        }

        public static bool operator ==(NumeroDecimal numD, NumeroBinario numB)
        {
            bool rv = false;
            if (numB == numD)
            {
                rv = true;
            }
            return rv;
        }

        public static bool operator !=(NumeroDecimal numD, NumeroBinario numB)
        {
            bool rv = true;
            if (numB != numD)
            {
                rv = false;
            }
            return rv;
        }
    }
}
