﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_47;

namespace Ejercicio_47_Console_
{
    class Program
    {
        static void Main(string[] args)
        {
            string mostrarTorneoFutbol = "";
            string mostrarTorneoBasquet = "";

            string resultadoDelPartidoDeFutbolUno = "";
            string resultadoDelPartidoDeFutbolDos = "";
            string resultadoDelPartidoDeFutbolTres = "";

            string resultadoDelPartidoDeBasquetUno = "";
            string resultadoDelPartidoDeBasquetDos = "";
            string resultadoDelPartidoDeBasquetTres = "";

            Torneo<EquipoFutbol> torneoFutbol = new Torneo<EquipoFutbol>("Torneo Barrio Unido");
            Torneo<EquipoBasquet> torneoBasquet = new Torneo<EquipoBasquet>("Torneo Basquet Lanus");

            EquipoFutbol equipoFutbolUno = new EquipoFutbol();
            EquipoFutbol equipoFutbolDos = new EquipoFutbol();
            EquipoFutbol equipoFutbolTres = new EquipoFutbol();

            EquipoBasquet equipoBasquetUno = new EquipoBasquet();
            EquipoBasquet equipoBasquetDos = new EquipoBasquet();
            EquipoBasquet equipoBasquetTres = new EquipoBasquet();

            torneoFutbol += equipoFutbolUno;
            torneoFutbol += equipoFutbolDos;
            torneoFutbol += equipoFutbolTres;

            torneoBasquet += equipoBasquetUno;
            torneoBasquet += equipoBasquetDos;
            torneoBasquet += equipoBasquetTres;

            mostrarTorneoFutbol = torneoFutbol.Mostrar();
            mostrarTorneoBasquet = torneoBasquet.Mostrar();

            Console.WriteLine("Torneo de Futbol: ", mostrarTorneoFutbol);
            Console.ReadKey();
            Console.WriteLine("Torneo de Basquet: ", mostrarTorneoBasquet);
            Console.ReadKey();

            resultadoDelPartidoDeFutbolUno = torneoFutbol.JugarPartido;
            resultadoDelPartidoDeFutbolDos = torneoFutbol.JugarPartido;
            resultadoDelPartidoDeFutbolTres = torneoFutbol.JugarPartido;

            resultadoDelPartidoDeBasquetUno = torneoBasquet.JugarPartido;
            resultadoDelPartidoDeBasquetDos = torneoBasquet.JugarPartido;
            resultadoDelPartidoDeBasquetTres = torneoBasquet.JugarPartido;

            Console.WriteLine("Partido de Futbol Uno: ", resultadoDelPartidoDeFutbolUno);
            Console.ReadKey();

            Console.WriteLine("Partido de Futbol Dos: ", resultadoDelPartidoDeFutbolDos);
            Console.ReadKey();

            Console.WriteLine("Partido de Futbol Tres: ", resultadoDelPartidoDeFutbolTres);
            Console.ReadKey();

            Console.WriteLine("Partido de Basquet Uno: ", resultadoDelPartidoDeBasquetUno);
            Console.ReadKey();

            Console.WriteLine("Partido de Basquet Dos: ", resultadoDelPartidoDeBasquetDos);
            Console.ReadKey();

            Console.WriteLine("Partido de Basquet Tres: ", resultadoDelPartidoDeBasquetTres);
            Console.ReadKey();
        }
    }
}
