﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_14;

namespace Ejercicio_14
{
    class Program
    {
        static void Main(string[] args)
        {
            double ladoDelCuadrado = 5;
            double baseDeUnTriangulo = 3;
            double alturaDeUnTriangulo = 5;
            double radioDeUnTriangulo = 5;
            double areaDeUnCuadrado;
            double areaDeUnTriangulo;
            double areDeUnCirculo;

            areaDeUnCuadrado = CalculoDeArea.CalcularCuadrado(ladoDelCuadrado);
            areaDeUnTriangulo = CalculoDeArea.CalcularTriangulo(baseDeUnTriangulo, alturaDeUnTriangulo);
            areDeUnCirculo = CalculoDeArea.CalcularCirculo(radioDeUnTriangulo);


            Console.WriteLine(areaDeUnCuadrado);
            Console.WriteLine(areaDeUnTriangulo);
            Console.WriteLine(areDeUnCirculo);
            Console.ReadKey();
        }
    }
    class CalculoDeArea
    {
        public static double CalcularCuadrado(double lado)
        {
            return lado * lado;
        }
        public static double CalcularTriangulo(double b, double altura)
        {
            double basePorAltura = b * altura;
            return basePorAltura/2;
        }
        public static double CalcularCirculo(double radio)
        {
            double radioAlCuadrado = radio * radio;
            double pi = 3.14;
            return radioAlCuadrado * pi;
        }

    }
}
