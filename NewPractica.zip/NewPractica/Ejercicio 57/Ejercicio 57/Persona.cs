﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Ejercicio_57
{
    [Serializable]
    public class Persona
    {
        private string nombre;
        private string apellido;

        public Persona(string nombre, string apellido)
        {
            this.nombre = nombre;
            this.apellido = apellido;
        }

        public static void Guardar(Persona persona)
        {
            BinaryFormatter personaASerializar; //objeto que serializara

            //se crea el objeto serializador.
            personaASerializar = new BinaryFormatter();

            //Indico ubicacion del archuvo y modo de apertura
            FileStream archivo = new FileStream("Persona.txt", FileMode.Create);//generando archivo donde guardo a la persona serializada
            
            //Serializo
            personaASerializar.Serialize(archivo, persona);
            
            //Cierro el archivo
            archivo.Close();
        }

        public static Persona Leer()
        {
            Persona persona;
            
            //Creo el objeto serializador
            BinaryFormatter personaADeserializar = new BinaryFormatter();
            
            //Indico ubicacion del archuvo y modo de apertura
            FileStream archivo = new FileStream("Persona.txt", FileMode.Open);
           
            //Deserializo
            persona = (Persona)personaADeserializar.Deserialize(archivo);//casteo para que sepa que es de tipo persona.
            
            //Cierro el archivo
            archivo.Close();

            return persona;
        }

        public override string ToString()
        {
            StringBuilder datos = new StringBuilder();
            datos.AppendLine("Nombre: " + this.nombre);
            datos.AppendLine("Apellido: " + this.apellido);
            return datos.ToString();
        }
    }
}
