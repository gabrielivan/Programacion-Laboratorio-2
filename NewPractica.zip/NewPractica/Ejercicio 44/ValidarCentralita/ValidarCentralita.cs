﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CentralitaHerencia;
using System.Collections.Generic;

namespace ValidarCentralita
{
    [TestClass]
    public class ValidarCentralita
    {
        [TestMethod]
        public void ValidarListaLlamada()
        {
            //Arrange 
            Centralita c = new Centralita("Fede Center");
            //Act 

            //Assert
            Assert.IsNotNull(c.Llamadas);
            Assert.IsInstanceOfType(c.Llamadas, typeof(List<Llamada>));
        }

        [TestMethod]
        public void ValidarSegundaLlamadaLocal()
        {
            //Arrange
            Centralita centralitaA = new Centralita("Gaby Telefono");
            Local l1 = new Local("Avellaneda", 30, "Neuquen", 2.65f);
            Local l2 = new Local("Avellaneda", 30, "Neuquen", 2.65f);

            //Act 
            try
            {
                centralitaA += l1;
                centralitaA += l2;
                Assert.Fail("No lanzo la excepcion real");
            }
            catch (AssertFailedException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Assert.IsInstanceOfType(ex, typeof(CentralitaException));
            }

            //Assert
        }

        [TestMethod]
        public void ValidarSegundaLlamadaProvincial()
        {
            //Arrange
            Centralita centralitaA = new Centralita("Gaby Telefono");
            Provincial l1 = new Provincial("Morón", Franja.Franja_1, 21, "Bernal");
            Provincial l2 = new Provincial("Morón", Franja.Franja_1, 21, "Bernal");

            //Act 
            try
            {
                centralitaA += l1;
                centralitaA += l2;
                Assert.Fail("No lanzo la excepcion real");
            }
            catch (AssertFailedException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Assert.IsInstanceOfType(ex, typeof(CentralitaException));
            }

            //Assert
        }

        [TestMethod]
        public void ValidarSegundaLlamadasLocalProvincial()
        {
            //Arrange
            Centralita centralitaA = new Centralita("Gaby Telefono");
            Local l1 = new Local("Avellaneda", 30, "Neuquen", 2.65f);
            Local l2 = new Local("Avellaneda", 30, "Neuquen", 2.65f);
            Provincial l3 = new Provincial("Avellaneda", Franja.Franja_1, 21, "Neuquen");
            Provincial l4 = new Provincial("Avellaneda", Franja.Franja_1, 21, "Neuquen");

            //Act 

                Assert.IsTrue(l1 == l2, "l1 == l2"); // true
                Assert.IsTrue(l3 == l4, "l3 == l4"); //true
                Assert.IsFalse(l1 == l3,"l1 == l3"); //false
                Assert.IsFalse(l1 == l4,"l1 == l4"); //false
                Assert.IsFalse(l2 == l3,"l2 == l3"); //false
                Assert.IsFalse(l2 == l4,"l2 == l4"); //false

            //Assert
        }
    }
}
