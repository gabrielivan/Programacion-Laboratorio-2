﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_34
{
    public class Moto : VehiculoTerrestre
    {
        short cilindradas;

        public Moto(short cantRuedas, short cantPuertas, Colores c, short cilindradas): base(cantRuedas, cantPuertas, c)
        {
            this.cilindradas = cilindradas;
        }

        public static string MostrarAtributos(Moto moto)
        {
            string cadena = "";
            cadena = "La cantidad de ruedas del auto son: " + moto.cantidadRuedas + "\n" + "La cantidad de puertas del auto son: " + moto.cantidadPuertas + "\n" + "El color del auto es: " + moto.color + "\n" + "la cantidad de cilindradas del auto son: " + moto.cilindradas + "\n";
            return cadena;
        }
    }
}
