﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_34
{
    public class VehiculoTerrestre
    {
        protected short cantidadPuertas;
        protected short cantidadRuedas;
        protected Colores color;

        public VehiculoTerrestre(short cantRuedas, short cantPuertas, Colores c)
        {
            this.cantidadRuedas = cantRuedas;
            this.cantidadPuertas = cantPuertas;
            this.color = c;
        }

        public enum Colores
        {
            Rojo,
            Blanco,
            Azul,
            Gris,
            Negro
        }
    }
}
