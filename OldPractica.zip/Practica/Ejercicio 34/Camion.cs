﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_34
{
    public class Camion : VehiculoTerrestre
    {
        int pesoCarga;
        short cantidadMarchas;

        public Camion(short cantRuedas, short cantPuertas, short cantMarchas, Colores c, int pCarga) : base(cantRuedas, cantPuertas, c)
        {
            this.cantidadMarchas = cantMarchas;
            this.pesoCarga = pCarga;
        }

        public static string MostrarAtributos(Camion camion)
        {
            string cadena = "";
            cadena = "La cantidad de ruedas del auto son: " + camion.cantidadRuedas + "\n" + "La cantidad de puertas del auto son: " + camion.cantidadPuertas + "\n" + "El color del auto es: " + camion.color + "\n" + "la cantidad de marchas del auto son: " + camion.cantidadMarchas + "\n" + "La cantidad de pasajeros son: " + camion.pesoCarga + "\n";
            return cadena;
        }
    }
}
