using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_19;


namespace Ejercicio_19
{
    class Program
    {
        static void Main(string[] args)
        {
            long numeroUno = 5;
            long numeroDos = 10;
            string cadenaUno = "Hola";
            string cadenaDos = "Mundo";
            string resultadoCad;
            long resultadoNum;

            Sumador PrimerSumador = new Sumador();
            resultadoNum = PrimerSumador.Sumar(numeroUno, numeroDos);
            resultadoCad = PrimerSumador.Sumar(cadenaUno, cadenaDos);

            Console.WriteLine(resultadoNum);
            Console.WriteLine(resultadoCad);
            Console.ReadKey();

            //Se supero la prueba con existo.

            //preguntarle a cris como probar la segunda parte??.
        }
        
    }
}
