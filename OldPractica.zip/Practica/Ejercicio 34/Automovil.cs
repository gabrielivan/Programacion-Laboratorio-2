﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_34
{
    public class Automovil : VehiculoTerrestre
    {
        short cantidadMarchas;
        int cantidadPasajeros;

        public Automovil(short cantRuedas, short cantPuertas, Colores c, short cantMarchas, int cantPasajeros) : base(cantRuedas, cantPuertas, c)
        {
            this.cantidadMarchas = cantMarchas;
            this.cantidadPasajeros = cantPasajeros;
        }

        public static string MostrarAtributos(Automovil auto)
        {
            string cadena = "";
            cadena = "La cantidad de ruedas del auto son: " + auto.cantidadRuedas + "\n" + "La cantidad de puertas del auto son: " + auto.cantidadPuertas + "\n" + "El color del auto es: " + auto.color + "\n" + "la cantidad de marchas del auto son: " + auto.cantidadMarchas + "\n" + "La cantidad de pasajeros son: " + auto.cantidadPasajeros + "\n";
            return cadena;
        }
    }
}
