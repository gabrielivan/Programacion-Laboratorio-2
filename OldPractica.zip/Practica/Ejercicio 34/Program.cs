﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_34
{
    class Program
    {
        static void Main(string[] args)
        {
            int cantidadPasajeros = 4;
            int pesoCarga = 2000;
            short cilindradas = 600;

            short cantidadRuedasAuto = 4;
            short cantidadRuedasCamion = 16;
            short cantidadRuedasMoto = 2;

            short cantidadPuertasAuto = 4;
            short cantidadPuertasCamion = 2;
            short cantidadPuertasMoto = 0;

            VehiculoTerrestre.Colores colorAuto = VehiculoTerrestre.Colores.Azul;
            VehiculoTerrestre.Colores colorCamion = VehiculoTerrestre.Colores.Rojo;
            VehiculoTerrestre.Colores colorMoto = VehiculoTerrestre.Colores.Blanco;

            short cantidadMarchasAuto = 5;
            short cantidadMarchasCamion = 4;

            Automovil auto = new Automovil(cantidadRuedasAuto, cantidadPuertasAuto, colorAuto, cantidadMarchasAuto, cantidadPasajeros);
            Camion camion = new Camion(cantidadRuedasCamion, cantidadPuertasCamion, cantidadMarchasCamion, colorCamion, pesoCarga);
            Moto moto = new Moto(cantidadRuedasMoto, cantidadPuertasMoto, colorMoto, cilindradas);

            string mostrarAuto = "";
            string mostrarCamion = "";
            string mostrarMoto = "";

            mostrarAuto = Automovil.MostrarAtributos(auto);
            mostrarCamion = Camion.MostrarAtributos(camion);
            mostrarMoto = Moto.MostrarAtributos(moto);
            Console.WriteLine(mostrarAuto);
            Console.WriteLine(mostrarCamion);
            Console.WriteLine(mostrarMoto);
            Console.ReadKey();
        }
    }
}
