﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTestClaseMetodo
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
