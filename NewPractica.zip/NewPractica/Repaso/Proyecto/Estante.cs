﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto
{
    class Estante
    {
        Producto[] productos;
        int ubicacionEstante;

        private Estante(int capacidad)
        {
            this.productos = new Producto[capacidad];
        }
        public Estante(int capacidad, int ubicacion):this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }

        public static bool operator ==(Estante e, Producto p)
        {
            bool rv = false;
            foreach (Producto producto in e.productos)
            {
                if (!Object.ReferenceEquals(producto, null))
                {
                    rv = producto == p;
                }
            }
            return rv;
        }
        public static bool operator !=(Estante e, Producto p)
        {
            return !(e == p);
        }
        public static bool operator +(Estante e, Producto p)
        {
            bool rv = false;
            for(int i = 0; i < e.productos.Length; i++)
            {
                if (e != p && Object.ReferenceEquals(e.productos[i], null))
                {
                    e.productos[i] = p;
                    rv = true;
                }
            }

            return rv;
        }
        public static bool operator -(Estante e, Producto p)
        {
            bool rv = false;
            for (int i = 0; i < e.productos.Length; i++)
            {
                if (e != p && Object.ReferenceEquals(e.productos[i], p))
                {
                    e.productos[i] = null;
                    rv = true;
                }
            }
            return rv;
        }

        public Producto[] GetProductos()
        {
            return this.productos;
        }

        public static string MostrarEstante(Estante e)
        {
            string cadenaUno = "";


            foreach (Producto producto in e.productos)
            {
                if (!Object.ReferenceEquals(producto, null))
                {
                    cadenaUno += Producto.MostrarProducto(producto) + "\n";
                }
            }
            cadenaUno += "\n" + "Ubicacion del Estante: " + "\n" + e.ubicacionEstante;

            return cadenaUno;
        }
    }
}
