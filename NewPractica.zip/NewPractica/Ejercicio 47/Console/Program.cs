﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_47;

namespace Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Torneo<EquipoFutbol> torneoSuperLiga = new Torneo<EquipoFutbol>("Copita de Leche");
            Torneo<EquipoBasquet> torneoSuperLigaDeBasquet = new Torneo<EquipoBasquet>("Copita de Leche Descremada");
            //Equipos de futtol
            EquipoFutbol racing = new EquipoFutbol("Racing", DateTime.Now);
            EquipoFutbol independiente = new EquipoFutbol("independiente", DateTime.Now);
            EquipoFutbol arsenal = new EquipoFutbol("Racing", DateTime.Now);
            //Equipos de basquet
            EquipoBasquet bocaBasquet = new EquipoBasquet("Boca Basquet", DateTime.Now);
            EquipoBasquet riverBasquet = new EquipoBasquet("River Basquet", DateTime.Now);
            EquipoBasquet modeloBasquet = new EquipoBasquet("Modelo Basquet", DateTime.Now);
            //Agrego equipos al torneo de futbol
            torneoSuperLiga += racing;
            torneoSuperLiga += independiente;
            torneoSuperLiga += arsenal;
            torneoSuperLiga += racing;
            //Agrego equipos al torneo de basquet
            torneoSuperLigaDeBasquet += riverBasquet;
            torneoSuperLigaDeBasquet += bocaBasquet;
            torneoSuperLigaDeBasquet += riverBasquet;
            torneoSuperLigaDeBasquet += modeloBasquet;

            System.Console.WriteLine("EQUIPOS DE FUTBOL");
            System.Console.WriteLine(racing.Ficha());
            System.Console.WriteLine(independiente.Ficha());
            System.Console.WriteLine(arsenal.Ficha());
            System.Console.ReadKey();
            System.Console.Clear();
            System.Console.WriteLine("EQUIPOS DE BASQUET");
            System.Console.WriteLine(bocaBasquet.Ficha());
            System.Console.WriteLine(riverBasquet.Ficha());
            System.Console.WriteLine(modeloBasquet.Ficha());
            System.Console.ReadKey();
            System.Console.Clear();

            System.Console.WriteLine(torneoSuperLiga.CalcularPartido(racing, independiente));
            System.Console.WriteLine(torneoSuperLiga.CalcularPartido(racing, arsenal));
            System.Console.ReadKey();
        }
    }
}