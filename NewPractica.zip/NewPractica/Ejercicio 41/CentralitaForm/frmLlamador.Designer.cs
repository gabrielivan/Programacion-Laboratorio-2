﻿namespace CentralitaForm
{
    partial class FrmLlamador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxNumeroDestino = new System.Windows.Forms.TextBox();
            this.groupBoxPanel = new System.Windows.Forms.GroupBox();
            this.botonAsterisco = new System.Windows.Forms.Button();
            this.botonNumeral = new System.Windows.Forms.Button();
            this.botonNumerico0 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.botonNumerico7 = new System.Windows.Forms.Button();
            this.botonNumerico5 = new System.Windows.Forms.Button();
            this.botonNumerico6 = new System.Windows.Forms.Button();
            this.botonNumerico4 = new System.Windows.Forms.Button();
            this.botonNumerico3 = new System.Windows.Forms.Button();
            this.botonNumerico2 = new System.Windows.Forms.Button();
            this.botonNumerico1 = new System.Windows.Forms.Button();
            this.botonLlamar = new System.Windows.Forms.Button();
            this.botonLimpiar = new System.Windows.Forms.Button();
            this.botonSalir = new System.Windows.Forms.Button();
            this.textBoxNroOrigen = new System.Windows.Forms.TextBox();
            this.comboBoxFranja = new System.Windows.Forms.ComboBox();
            this.groupBoxPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxNumeroDestino
            // 
            this.textBoxNumeroDestino.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNumeroDestino.Location = new System.Drawing.Point(10, 7);
            this.textBoxNumeroDestino.Name = "textBoxNumeroDestino";
            this.textBoxNumeroDestino.Size = new System.Drawing.Size(265, 31);
            this.textBoxNumeroDestino.TabIndex = 0;
            this.textBoxNumeroDestino.Text = "Nro Destino";
            // 
            // groupBoxPanel
            // 
            this.groupBoxPanel.Controls.Add(this.botonAsterisco);
            this.groupBoxPanel.Controls.Add(this.botonNumeral);
            this.groupBoxPanel.Controls.Add(this.botonNumerico0);
            this.groupBoxPanel.Controls.Add(this.button9);
            this.groupBoxPanel.Controls.Add(this.button8);
            this.groupBoxPanel.Controls.Add(this.botonNumerico7);
            this.groupBoxPanel.Controls.Add(this.botonNumerico5);
            this.groupBoxPanel.Controls.Add(this.botonNumerico6);
            this.groupBoxPanel.Controls.Add(this.botonNumerico4);
            this.groupBoxPanel.Controls.Add(this.botonNumerico3);
            this.groupBoxPanel.Controls.Add(this.botonNumerico2);
            this.groupBoxPanel.Controls.Add(this.botonNumerico1);
            this.groupBoxPanel.Location = new System.Drawing.Point(12, 44);
            this.groupBoxPanel.Name = "groupBoxPanel";
            this.groupBoxPanel.Size = new System.Drawing.Size(120, 142);
            this.groupBoxPanel.TabIndex = 1;
            this.groupBoxPanel.TabStop = false;
            this.groupBoxPanel.Text = "Panel";
            // 
            // botonAsterisco
            // 
            this.botonAsterisco.Location = new System.Drawing.Point(7, 107);
            this.botonAsterisco.Name = "botonAsterisco";
            this.botonAsterisco.Size = new System.Drawing.Size(29, 23);
            this.botonAsterisco.TabIndex = 9;
            this.botonAsterisco.Text = "*";
            this.botonAsterisco.UseVisualStyleBackColor = true;
            this.botonAsterisco.Click += new System.EventHandler(this.botonAsterisco_Click);
            // 
            // botonNumeral
            // 
            this.botonNumeral.Location = new System.Drawing.Point(77, 107);
            this.botonNumeral.Name = "botonNumeral";
            this.botonNumeral.Size = new System.Drawing.Size(29, 23);
            this.botonNumeral.TabIndex = 11;
            this.botonNumeral.Text = "#";
            this.botonNumeral.UseVisualStyleBackColor = true;
            this.botonNumeral.Click += new System.EventHandler(this.botonNumeral_Click);
            // 
            // botonNumerico0
            // 
            this.botonNumerico0.Location = new System.Drawing.Point(42, 107);
            this.botonNumerico0.Name = "botonNumerico0";
            this.botonNumerico0.Size = new System.Drawing.Size(29, 23);
            this.botonNumerico0.TabIndex = 10;
            this.botonNumerico0.Text = "0";
            this.botonNumerico0.UseVisualStyleBackColor = true;
            this.botonNumerico0.Click += new System.EventHandler(this.botonNumerico0_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(77, 78);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(29, 23);
            this.button9.TabIndex = 8;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(42, 78);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(29, 23);
            this.button8.TabIndex = 7;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // botonNumerico7
            // 
            this.botonNumerico7.Location = new System.Drawing.Point(7, 78);
            this.botonNumerico7.Name = "botonNumerico7";
            this.botonNumerico7.Size = new System.Drawing.Size(29, 23);
            this.botonNumerico7.TabIndex = 6;
            this.botonNumerico7.Text = "7";
            this.botonNumerico7.UseVisualStyleBackColor = true;
            this.botonNumerico7.Click += new System.EventHandler(this.botonNumerico7_Click);
            // 
            // botonNumerico5
            // 
            this.botonNumerico5.Location = new System.Drawing.Point(42, 49);
            this.botonNumerico5.Name = "botonNumerico5";
            this.botonNumerico5.Size = new System.Drawing.Size(29, 23);
            this.botonNumerico5.TabIndex = 4;
            this.botonNumerico5.Text = "5";
            this.botonNumerico5.UseVisualStyleBackColor = true;
            this.botonNumerico5.Click += new System.EventHandler(this.botonNumerico5_Click);
            // 
            // botonNumerico6
            // 
            this.botonNumerico6.Location = new System.Drawing.Point(77, 49);
            this.botonNumerico6.Name = "botonNumerico6";
            this.botonNumerico6.Size = new System.Drawing.Size(29, 23);
            this.botonNumerico6.TabIndex = 5;
            this.botonNumerico6.Text = "6";
            this.botonNumerico6.UseVisualStyleBackColor = true;
            this.botonNumerico6.Click += new System.EventHandler(this.botonNumerico6_Click);
            // 
            // botonNumerico4
            // 
            this.botonNumerico4.Location = new System.Drawing.Point(7, 49);
            this.botonNumerico4.Name = "botonNumerico4";
            this.botonNumerico4.Size = new System.Drawing.Size(29, 23);
            this.botonNumerico4.TabIndex = 3;
            this.botonNumerico4.Text = "4";
            this.botonNumerico4.UseVisualStyleBackColor = true;
            this.botonNumerico4.Click += new System.EventHandler(this.botonNumerico4_Click);
            // 
            // botonNumerico3
            // 
            this.botonNumerico3.Location = new System.Drawing.Point(77, 20);
            this.botonNumerico3.Name = "botonNumerico3";
            this.botonNumerico3.Size = new System.Drawing.Size(29, 23);
            this.botonNumerico3.TabIndex = 2;
            this.botonNumerico3.Text = "3";
            this.botonNumerico3.UseVisualStyleBackColor = true;
            this.botonNumerico3.Click += new System.EventHandler(this.botonNumerico3_Click);
            // 
            // botonNumerico2
            // 
            this.botonNumerico2.Location = new System.Drawing.Point(42, 20);
            this.botonNumerico2.Name = "botonNumerico2";
            this.botonNumerico2.Size = new System.Drawing.Size(29, 23);
            this.botonNumerico2.TabIndex = 1;
            this.botonNumerico2.Text = "2";
            this.botonNumerico2.UseVisualStyleBackColor = true;
            this.botonNumerico2.Click += new System.EventHandler(this.botonNumerico2_Click);
            // 
            // botonNumerico1
            // 
            this.botonNumerico1.Location = new System.Drawing.Point(7, 20);
            this.botonNumerico1.Name = "botonNumerico1";
            this.botonNumerico1.Size = new System.Drawing.Size(29, 23);
            this.botonNumerico1.TabIndex = 0;
            this.botonNumerico1.Text = "1";
            this.botonNumerico1.UseVisualStyleBackColor = true;
            this.botonNumerico1.Click += new System.EventHandler(this.botonNumerico1_Click);
            // 
            // botonLlamar
            // 
            this.botonLlamar.Location = new System.Drawing.Point(168, 64);
            this.botonLlamar.Name = "botonLlamar";
            this.botonLlamar.Size = new System.Drawing.Size(107, 23);
            this.botonLlamar.TabIndex = 0;
            this.botonLlamar.Text = "Llamar";
            this.botonLlamar.UseVisualStyleBackColor = true;
            this.botonLlamar.Click += new System.EventHandler(this.botonLlamar_Click);
            // 
            // botonLimpiar
            // 
            this.botonLimpiar.Location = new System.Drawing.Point(168, 93);
            this.botonLimpiar.Name = "botonLimpiar";
            this.botonLimpiar.Size = new System.Drawing.Size(107, 23);
            this.botonLimpiar.TabIndex = 1;
            this.botonLimpiar.Text = "Limpiar";
            this.botonLimpiar.UseVisualStyleBackColor = true;
            this.botonLimpiar.Click += new System.EventHandler(this.botonLimpiar_Click);
            // 
            // botonSalir
            // 
            this.botonSalir.Location = new System.Drawing.Point(168, 151);
            this.botonSalir.Name = "botonSalir";
            this.botonSalir.Size = new System.Drawing.Size(107, 23);
            this.botonSalir.TabIndex = 3;
            this.botonSalir.Text = "Salir";
            this.botonSalir.UseVisualStyleBackColor = true;
            this.botonSalir.Click += new System.EventHandler(this.botonSalir_Click);
            // 
            // textBoxNroOrigen
            // 
            this.textBoxNroOrigen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNroOrigen.Location = new System.Drawing.Point(168, 122);
            this.textBoxNroOrigen.Name = "textBoxNroOrigen";
            this.textBoxNroOrigen.Size = new System.Drawing.Size(107, 21);
            this.textBoxNroOrigen.TabIndex = 15;
            this.textBoxNroOrigen.Text = "Nro Origen";
            // 
            // comboBoxFranja
            // 
            this.comboBoxFranja.FormattingEnabled = true;
            this.comboBoxFranja.Location = new System.Drawing.Point(13, 209);
            this.comboBoxFranja.Name = "comboBoxFranja";
            this.comboBoxFranja.Size = new System.Drawing.Size(262, 21);
            this.comboBoxFranja.TabIndex = 2;
            // 
            // FrmLlamador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(289, 244);
            this.Controls.Add(this.comboBoxFranja);
            this.Controls.Add(this.textBoxNroOrigen);
            this.Controls.Add(this.botonSalir);
            this.Controls.Add(this.botonLimpiar);
            this.Controls.Add(this.botonLlamar);
            this.Controls.Add(this.groupBoxPanel);
            this.Controls.Add(this.textBoxNumeroDestino);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmLlamador";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Llamador";
            this.Load += new System.EventHandler(this.FrmLlamador_Load);
            this.groupBoxPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxNumeroDestino;
        private System.Windows.Forms.GroupBox groupBoxPanel;
        private System.Windows.Forms.Button botonAsterisco;
        private System.Windows.Forms.Button botonNumeral;
        private System.Windows.Forms.Button botonNumerico0;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button botonNumerico7;
        private System.Windows.Forms.Button botonNumerico5;
        private System.Windows.Forms.Button botonNumerico6;
        private System.Windows.Forms.Button botonNumerico4;
        private System.Windows.Forms.Button botonNumerico3;
        private System.Windows.Forms.Button botonNumerico2;
        private System.Windows.Forms.Button botonNumerico1;
        private System.Windows.Forms.Button botonLlamar;
        private System.Windows.Forms.Button botonLimpiar;
        private System.Windows.Forms.Button botonSalir;
        private System.Windows.Forms.TextBox textBoxNroOrigen;
        private System.Windows.Forms.ComboBox comboBoxFranja;
    }
}