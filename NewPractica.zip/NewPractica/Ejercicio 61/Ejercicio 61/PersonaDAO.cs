﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace Ejercicio_61
{
    public class PersonaDAO
    {
        public static SqlConnection conexion;
        public static SqlCommand comando;

        static PersonaDAO()
        {
            string connectionStr = @"Data Source=.\SQLEXPRESS; Initial Catalog=Persona; Integrated Security = True";

            try
            {
                conexion = new SqlConnection(connectionStr);
                comando = new SqlCommand();
                comando.CommandType = System.Data.CommandType.Text;
                comando.Connection = conexion;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static bool Guardar(string nombre, string apellido)
        {
            bool respuesta = false;

            try
            {
                string insertarPersona = String.Format("INSERT INTO Table_Persona (Nombre, Apellido) VALUES ('{0}','{1}')", nombre, apellido);
                comando.CommandText = insertarPersona;
                conexion.Open();
                comando.ExecuteNonQuery();
                respuesta = true;
            }

            catch (Exception e)
            {
                throw e;
            }

            finally
            {
                conexion.Close();
            }

            return respuesta;
        }

        public static List<Persona> Leer()
        {
            List<Persona> personas = new List<Persona>();
            Persona persona;

            string consulta = String.Format("Select * from Table_Persona");
            try
            {
                comando.CommandText = consulta;
                conexion.Open();
                SqlDataReader oDr = comando.ExecuteReader();

                while (oDr.Read())
                {
                    int id = int.Parse(oDr["ID"].ToString());
                    string nombre = oDr["Nombre"].ToString();
                    string apellido = oDr["Apellido"].ToString();
                    persona = new Persona(id, nombre, apellido);
                    personas.Add(persona);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexion.Close();
            }

            return personas;
        }

        public static Persona LeerPorId(int id)
        {
            Persona persona = null;

            string consulta = String.Format("SELECT * FROM Table_Persona WHERE Id = {0}", id);
            try
            {
                comando.CommandText = consulta;
                conexion.Open();
                SqlDataReader oDr = comando.ExecuteReader();

                while (oDr.Read())
                {
                    string nombre = oDr["Nombre"].ToString();
                    string apellido = oDr["Apellido"].ToString();
                    persona = new Persona(id, nombre, apellido);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexion.Close();
            }

            return persona;
        }

        public static bool Modificar(Persona persona)
        {
            bool respuesta = false;

            try
            {
                string updatePersona = String.Format("UPDATE Table_Persona SET Nombre = '{0}', Apellido = '{1}' WHERE ID = '{2}'", persona.Nombre, persona.Apellido, persona.ID);
                comando.CommandText = updatePersona;
                conexion.Open();
                comando.ExecuteNonQuery();
                respuesta = true;
            }

            catch (Exception e)
            {
                throw e;
            }

            finally
            {
                conexion.Close();
            }

            return respuesta;
        }

        public static bool borrar(int id)
        {
            bool respuesta = false;

            try
            {
                string consulta = String.Format("DELETE FROM Table_Persona WHERE ID = {0}", id);
                comando.CommandText = consulta;
                conexion.Open();
                comando.ExecuteNonQuery();
                respuesta = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexion.Close();
            }
            return respuesta;
        }

    }
}
