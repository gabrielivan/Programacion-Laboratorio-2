﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_22
{
    class NumeroBinario
    {
        private string numero;

        private NumeroBinario(string s)
        {
            this.numero = s;
        }

        public static implicit operator NumeroBinario(string cadena)
        {
            return new NumeroBinario(cadena);
        }

        public static explicit operator string(NumeroBinario numB)
        {
            return numB.numero;
        }


        public static string operator +(NumeroBinario numB, NumeroDecimal numD)
        {
            return numB + numD;
        }

        public static string operator -(NumeroBinario numB, NumeroDecimal numD)
        {
            return numB - numD;
        }

        public static bool operator ==(NumeroBinario numB, NumeroDecimal numD)
        {
            bool rv = false;
            if(numB == numD)
            {
                rv = true;
            }
            return rv;
        }

        public static bool operator !=(NumeroBinario numB, NumeroDecimal numD)
        {
            bool rv = true;
            if (numB != numD)
            {
                rv = false;
            }
            return rv;
        }
    }
}
