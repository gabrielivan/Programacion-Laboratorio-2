﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_13;

namespace Ejercicio_13
{
    class Program
    {
        static void Main(string[] args)
        {
            string cadena;
            double numero = 10;
            cadena = Conversor.DecimalBinario(numero);
            Console.WriteLine(cadena);
            Console.ReadKey();

            string binario = "1010";
            double numero2;
            numero2 = Conversor.BinarioDecimal(binario);
            Console.WriteLine(numero2);
            Console.ReadKey();
        }
    }
    public class Conversor
    {
        public static string DecimalBinario(double d)
        {
            string cadena;

            if (d > 0)
            {
                cadena = "";
                while (d > 0)
                {
                    if (d % 2 == 0)
                    {
                        cadena = "0" + cadena;
                    }
                    else
                    {
                        cadena = "1" + cadena;
                    }
                    d = (int)(d / 2);
                }
                return cadena;
            }
            else
            {
                if (d == 0)
                {
                    cadena = "0";                   
                }
                else
                {
                    cadena = "Ingrese solo numeros positivos";
                    Console.ReadLine();
                }
                return cadena;
            }

        }

        public static double BinarioDecimal(string binario)
        {
            char[] array = binario.ToCharArray();
            Array.Reverse(array);
            int suma = 0;

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == '1')
                {
                    suma += (int)Math.Pow(2, i);
                }
            }
            return suma;
        }

    }
}

