﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_47
{
    public abstract class Equipo
    {
        string nombre;
        DateTime fechaDeCreacion;

        public static bool operator ==(Equipo equipoUno, Equipo equipoDos)
        {
            bool retorno = false;

            if (equipoUno.nombre == equipoDos.nombre && equipoUno.fechaDeCreacion == equipoDos.fechaDeCreacion)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Equipo equipoUno, Equipo equipoDos)
        {
            return !(equipoUno == equipoDos);
        }

        public string Ficha()
        {
            return String.Format("[EQUIPO {0}] fundado el {1}", this.nombre, this.fechaDeCreacion);
        }

    }
}
