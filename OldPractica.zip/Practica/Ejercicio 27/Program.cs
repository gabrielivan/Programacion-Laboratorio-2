﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_27
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<int> cola = new Queue<int>();
            List<int> intList = new List<int>();
            Random random = new Random();

            for (int i = 0; i < 20; i++)
            {
                int randomNumber = random.Next(-100, 100);
                cola.Enqueue(randomNumber);
            }

            Console.WriteLine("Antes de ordenar \n");

            foreach (var num in cola)
            {
                Console.WriteLine(num);
            }
            Console.ReadKey();

            Console.WriteLine("HAGO UNA LISTA CON LA COLA QUE TENGO \n");
            cola.ToList();


            intList.Sort();
            intList.Reverse();
            Console.WriteLine("\n Despues de ordenar decendente los positivos\n");
            foreach (var num in intList)
            {
                if (num >= 0)
                    Console.WriteLine(num);
            }
            Console.ReadKey();

            intList.Sort();
            Console.WriteLine("Despues de ordenar acendiente los negativos\n");
            foreach (var num in intList)
            {
                if (num <= 0)
                    Console.WriteLine(num);
            }
            Console.ReadKey();
        }
    }
}
