﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using IO;

namespace VistaConsola
{
    class Program
    {
        static void Main(string[] args)
        {
            ///EN MI PC
            string nombreArchivo = ("C:\\Users\\chris_x4urr38\\Desktop\\" + DateTime.Now.ToString("yyyyMMdd-Hmm") + ".txt");
            ///FACULTAD
            //string nombreArchivo = ("C:\\" + DateTime.Now.ToString("yyyyMMdd-Hmm") + ".txt");
            ClaseMetodo test;

            try
            {
                test = new ClaseMetodo();
                test.MetodoInstancia(1);
            }
            catch(MiExcepcion excepcion)
            {
                ArchivoTexto.Guardar(nombreArchivo, excepcion.Message);

                if (!object.ReferenceEquals(excepcion.InnerException, null))
                {
                    Exception auxiliar = excepcion.InnerException;

                    do
                    {
                        ArchivoTexto.Guardar(nombreArchivo, auxiliar.Message);
                        auxiliar = auxiliar.InnerException;

                    } while (!object.ReferenceEquals(auxiliar, null));
                }

            }
            Console.WriteLine(ArchivoTexto.Leer(nombreArchivo));
            Console.ReadKey();
        }
    }
}
