using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_11;

namespace Ejercicio_11
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            string aux;
            int numero;
            int validacionMinimo = -100;
            int validacionMaximo = 100;
            int min = int.MinValue;
            int max = int.MaxValue;
            int acumulador = 0;
            int promedio = 0;
            bool esValido = false;
            bool flag = true;
            do
            {
                Console.WriteLine("Ingresar un numero entre -100 y 100: ");
                aux = Console.ReadLine();

                bool trueOrFalse = int.TryParse(aux, out numero);
                if (trueOrFalse)
                {
                    esValido = Validacion.Validar(numero, validacionMinimo, validacionMaximo);

                    if (esValido)
                    {
                        acumulador = acumulador + numero;

                        if (flag)
                        {
                            min = numero;
                            max = numero;
                            flag = false;
                        }
                        else
                        {
                            if (numero < min)
                            {
                                min = numero;
                            }
                            else if (numero > max)
                            {
                                max = numero;
                            }
                            
                        }
                        i = i + 1;
                    }
                    else
                    {
                        Console.WriteLine("El numero que se ingreso no es valido!");
                    }

                }
                 
            } while (i < 10);

            promedio = acumulador / 10;

            Console.WriteLine("El numero maximo es: " + max);
            Console.WriteLine("El numero maximo es: " + min);
            Console.WriteLine("El promedio es: " + promedio);
            Console.ReadKey();
        }
    }
    public class Validacion
    {
        public static bool Validar(int valor, int min, int max)
        {
            var rv = false;

            if (valor >= min && valor <= max)
            {
                rv = true;
            }
            return rv;
        }
    }
}
