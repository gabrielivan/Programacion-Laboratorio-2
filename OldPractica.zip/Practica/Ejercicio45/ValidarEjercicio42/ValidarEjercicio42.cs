﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace ValidarEjercicio42
{
    [TestClass]
    public class ValidarEjercicio42
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
