﻿namespace Notepad
{
    partial class FormNotePad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItemArchivo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemAbrir = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemGuardar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4GuardaComo = new System.Windows.Forms.ToolStripMenuItem();
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelCaracteres = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemArchivo});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(578, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItemArchivo
            // 
            this.toolStripMenuItemArchivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemAbrir,
            this.toolStripMenuItemGuardar,
            this.toolStripMenuItem4GuardaComo});
            this.toolStripMenuItemArchivo.Name = "toolStripMenuItemArchivo";
            this.toolStripMenuItemArchivo.Size = new System.Drawing.Size(60, 20);
            this.toolStripMenuItemArchivo.Text = "Archivo";
            // 
            // toolStripMenuItemAbrir
            // 
            this.toolStripMenuItemAbrir.Name = "toolStripMenuItemAbrir";
            this.toolStripMenuItemAbrir.Size = new System.Drawing.Size(159, 22);
            this.toolStripMenuItemAbrir.Text = "Abrir";
            this.toolStripMenuItemAbrir.Click += new System.EventHandler(this.toolStripMenuItemAbrir_Click);
            // 
            // toolStripMenuItemGuardar
            // 
            this.toolStripMenuItemGuardar.Name = "toolStripMenuItemGuardar";
            this.toolStripMenuItemGuardar.Size = new System.Drawing.Size(159, 22);
            this.toolStripMenuItemGuardar.Text = "Guardar";
            this.toolStripMenuItemGuardar.Click += new System.EventHandler(this.toolStripMenuItemGuardar_Click);
            // 
            // toolStripMenuItem4GuardaComo
            // 
            this.toolStripMenuItem4GuardaComo.Name = "toolStripMenuItem4GuardaComo";
            this.toolStripMenuItem4GuardaComo.Size = new System.Drawing.Size(159, 22);
            this.toolStripMenuItem4GuardaComo.Text = "Guardar como...";
            this.toolStripMenuItem4GuardaComo.Click += new System.EventHandler(this.toolStripMenuItem4GuardaComo_Click);
            // 
            // richTextBox
            // 
            this.richTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox.Location = new System.Drawing.Point(0, 24);
            this.richTextBox.Name = "richTextBox";
            this.richTextBox.Size = new System.Drawing.Size(578, 401);
            this.richTextBox.TabIndex = 2;
            this.richTextBox.Text = "";
            this.richTextBox.TextChanged += new System.EventHandler(this.richTextBox_TextChanged);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelCaracteres});
            this.statusStrip1.Location = new System.Drawing.Point(0, 403);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(578, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabelCaracteres
            // 
            this.toolStripStatusLabelCaracteres.Name = "toolStripStatusLabelCaracteres";
            this.toolStripStatusLabelCaracteres.Size = new System.Drawing.Size(69, 17);
            this.toolStripStatusLabelCaracteres.Text = "0 caracteres";
            // 
            // FormNotePad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 425);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.richTextBox);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormNotePad";
            this.Text = "NotePad Gabriel";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.RichTextBox richTextBox;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemArchivo;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemAbrir;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemGuardar;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4GuardaComo;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelCaracteres;
    }
}

