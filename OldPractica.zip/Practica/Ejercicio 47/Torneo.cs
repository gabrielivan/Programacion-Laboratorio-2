﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Ejercicio_47
{
    public class Torneo<T> where T : Equipo
    {
        public List<T> equipos = new List<T>();
        public string nombre;

        public Torneo(string nombre)
        {
            this.nombre = nombre;
        }

        public static bool operator ==(Torneo<T> torneo, T equipo)
        {
            bool retorno = false;

            foreach (T e in torneo.equipos)
            {
                if (torneo.equipos.Contains(equipo))
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Torneo<T> torneo, T equipo)
        {
            return !(torneo == equipo);
        }

        public static Torneo<T> operator +(Torneo<T> torneo, T equipo)
        {
            foreach (T e in torneo.equipos)
            {
                if (!torneo.equipos.Contains(e))
                {
                    torneo.equipos.Add(equipo);
                }
            }

            return torneo;
        }

        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Nombre del torneo: " + this.nombre);

            foreach (T equipo in this.equipos)
            {
                sb.AppendLine(equipo.Ficha());
            }
            return sb.ToString();
        }

        private string CalcularPartido(T primerElemento, T segundoElemento)
        {
            Random random = new Random();
            int resultadoUno = random.Next();
            Thread.Sleep(2000);
            int resultadoDos = random.Next();

            return String.Format("[EQUIPO1 {0}] [RESULTADO1 {1}] [RESULTADO {2}] [EQUIPO2 {3}]", primerElemento, resultadoUno, resultadoDos, segundoElemento);
        }

        public string JugarPartido
        {
            get
            {
                Random random = new Random();
                int indiceUno = random.Next();
                Thread.Sleep(2000);
                int indiceDos = random.Next();
                string resultado = "";

                T equipoUno;
                T equipoDos;

                if (this.equipos.Count > indiceUno && this.equipos.Count > indiceDos)
                {
                    equipoUno = equipos.ElementAt(indiceUno);
                    equipoDos = equipos.ElementAt(indiceDos);
                }
                else
                {
                    return "";
                }
              
                resultado = CalcularPartido(equipoUno, equipoDos);

                return resultado;
            }
        }
    }
}
