﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
            string mostrarAlumnoUno;
            string mostrarAlumnoDos;
            string mostrarAlumnoTres;

            Alumno alumnoUno = new Alumno("Damian","Desario",100);
            Alumno alumnoDos = new Alumno("Alejandro","Torres",101);
            Alumno alumnoTres = new Alumno("Leandro","Egea",102);

            alumnoUno.Estudiar(6,8);
            alumnoDos.Estudiar(7,8);
            alumnoTres.Estudiar(8,9);

            alumnoUno.CalcularFinal();
            System.Threading.Thread.Sleep(200);
            alumnoDos.CalcularFinal();
            System.Threading.Thread.Sleep(200);
            alumnoTres.CalcularFinal();
            System.Threading.Thread.Sleep(200);

            mostrarAlumnoUno = alumnoUno.Mostrar();
            Console.WriteLine(mostrarAlumnoUno);
            Console.ReadKey();

            mostrarAlumnoDos = alumnoDos.Mostrar();
            Console.WriteLine(mostrarAlumnoDos);
            Console.ReadKey();

            mostrarAlumnoTres = alumnoTres.Mostrar();
            Console.WriteLine(mostrarAlumnoTres);
            Console.ReadKey();

        }
    }

}
